#include <stdio.h>

int main() {
    int num = 7; // Initial value of the variable

    // Decrement thrice using the decrement operator
    num--;
    num++;
    num--;

    // Print the final value of the variable
    printf("The final value of the variable is: %d\n", num);
}