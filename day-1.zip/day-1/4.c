#include <stdio.h>

int main() {
    int num = 5; // Initial value of the variable

    // Increment by 3 using the += operator
    num += 3;

    // Multiply by 2 using the *= operator
    num *= 2;

    // Print the final value of the variable
    printf("The final value of the variable is: %d\n", num);
}
